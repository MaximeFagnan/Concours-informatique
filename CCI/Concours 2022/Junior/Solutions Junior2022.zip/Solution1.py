# -*- coding: utf-8 -*-
"""
Created on Sun Dec 11 01:04:38 2022

@author: Maxime Fagnan
@email: fagnan.maxime@courrier.uqam.ca
@email: maxime.fagnan@brebeuf.qc.ca

"""

normal=int(input())
petite=int(input())

nb=normal*8+petite*3

print(nb-28)