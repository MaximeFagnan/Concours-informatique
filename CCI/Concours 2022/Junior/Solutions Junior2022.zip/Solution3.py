# -*- coding: utf-8 -*-
"""
Created on Sun Dec 11 00:35:51 2022

@author: Maxime Fagnan
@email: fagnan.maxime@courrier.uqam.ca
@email: maxime.fagnan@brebeuf.qc.ca

"""

#--- definitions ---

#--- debut ---

entree=input()
nb=""
cordes=""
operation=""
for s in entree:
    if(s.isalpha()):
        #Si tu analyse une lettre après un chiffre
        if(nb != ""):
            #Imprime l'opération emmagasiner
            print(str(cordes)+" "+operation+" "+ nb)
            #RESET pour emmagasiner la prochaine operation
            nb=""
            cordes=""
        #Ajouter la corde à modifier
        cordes+=s
    if(s=="+"):
        operation="tighten"
    if(s=="-"):
        operation="loosen"
    if(s.isdigit()):
        nb=str(nb)+s

#imprimer la dernière operation
print(str(cordes)+" "+operation+" "+ nb)